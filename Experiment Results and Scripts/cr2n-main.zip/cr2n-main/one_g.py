import numpy as np
from sklearn.model_selection import KFold
from src.run import train, test, test_rule
import pandas as pd
import requests
from io import BytesIO
from zipfile import ZipFile
import os
from src.util import load_checkpoint, save_checkpoint, compute_metrics
from src.models import LocalModel
from src.data.datasets import UCIAnticancerDataset
from src.data.util import construct_data,construct_loader     
from torch.utils.data import DataLoader
# compute_metrics
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score
from src.data.datasets import SequenceDataset
from tqdm import tqdm
def ovotest(rule, test_loader):
    labels = [1.0, 0.0]
    x_test = list(map(lambda data: data[0].numpy(), test_loader.dataset))
    y_test = list(map(lambda data: data[1].item(), test_loader.dataset))

    y_pred, rules_triggered = rule.batch_apply_rule(x_test)
    y_pred = list(map(float, y_pred))
    res = compute_metrics(y_test, y_pred, labels)
    return y_pred
from src.models import GlobalModel    


def classify(datasetname):
    df = pd.read_csv("dataset/{}.csv".format(datasetname))
    batch_size=100
    # 5-fold cross validation
    seq = df['sequence'].values
    # splilt seq by " "
    seq = [i.split(" ") for i in seq]
    # remove " "
    seq = [[j for j in i if j != ""] for i in seq]
    df['sequence'] = seq
    dataset = UCIAnticancerDataset(df)
    data, y, dictionary = dataset.get_data(df)
    kf = KFold(n_splits=5, shuffle=True)
    dic={}
    acc_list = []
    for train_index, test_index in kf.split(data):

        X_train, X_test = np.array(data)[train_index], np.array(data)[test_index]
        y_train, y_test = np.array(y)[train_index], np.array(y)[test_index]
        test_dataset = SequenceDataset(X_test, y_test, dictionary)
        test_loader = construct_loader(test_dataset, indices=None, batch_size=batch_size)
        total_num_of_rules = 0
        # devide the data into class number of parts
        class_num = len(set(y_train))
        x_seq_for_each_class = []
        dict_y_train = set(y_train)

        for i in dict_y_train:
            x_seq_for_each_class.append(X_train[y_train == i])
        # generate the train, val with 1-1 combination
        rule_num = 0
        for i in range(0,class_num):
            for j in range(i+1,class_num):
                print("class {} vs class {}".format(i,j) )
                ij_x_train = np.concatenate((x_seq_for_each_class[i], x_seq_for_each_class[j]))

                ij_y_train = np.concatenate((np.zeros(len(x_seq_for_each_class[i])), np.ones(len(x_seq_for_each_class[j]))),dtype=float)
                #  sampler = BucketBatchSampler(np.array(dataset.x, dtype=object), batch_size)
                #  loader = DataLoader(dataset, batch_sampler=sampler, batch_size=1)
                # generate ij_dataset for ij_loader
                ij_dataset = SequenceDataset(ij_x_train, ij_y_train, dictionary)
                loader = construct_loader(ij_dataset, indices=None, batch_size=batch_size)
                # ##########################################################
                input_size = len(ij_dataset.features_name)
                window_size = 3
                base_model_hidden_size = window_size * 2
                base_or_output_size=1
                output_size=1

                pad_border = True

                max_sequence_length =  max([len(x) for x in dataset.x])

                # Compute dimension of convOR input size
                conv_dim_out = max_sequence_length - (window_size - 1)
                if pad_border:
                    conv_dim_out = conv_dim_out + (window_size - 1) * 2
                # ##########################################################
                from src.sparsify import Pruning
                pruning = Pruning()
                pruning30 = Pruning(start=30)
                pruning_strategy = pruning30
                epochs = 200
                local_model = GlobalModel(input_size, window_size, pad_border, max_sequence_length, base_model_hidden_size, conv_dim_out, base_or_output_size, output_size)
                train(local_model, loader, loader, pruning=pruning_strategy, epochs=epochs, verbose=True)
                rule, len_rule = local_model.extract_rule(features_names=dataset.features_name, verbose=False)
                total_num_of_rules += len_rule
                print(i,j)
                dic[(i,j)]= rule # save the model

        # test
        vote=np.zeros([len(X_test),class_num])
        
        for i in range(0,class_num):
            for j in range(i+1,class_num):
                rule = dic[(i,j)]
                res = ovotest(rule, test_loader)
                index = np.where(np.array(res) == 0.0)
                vote[index,i] += 1
                index = np.where(np.array(res) == 1.0)
                vote[index,j] += 1
        print(vote)
        y_pred = np.argmax(vote, axis=1)
        acc = accuracy_score(y_test, y_pred)
        acc_list.append(acc)
        print("accuracy: {}".format(accuracy_score(y_test, y_pred)))
    # save acc list

    print("mean acc: {}".format(np.mean(acc_list)))
    # print("mean length of rules: {}".format(total_num_of_rules/5))
    # file = open("result/{}.txt".format(datasetname), "w")
    # file.write("mean acc: {}".format(np.mean(acc_list)))
    # file.write("mean length of rules: {}".format(total_num_of_rules/5))
    return np.mean(acc_list)

if __name__ == "__main__":
    datasets = ['auslan2','aslbu','pioneer'	,'context'	,'robot'	,'epitope'	,'skating'	,'question'	,'unix'	,'gene'	,'reuters']
    
    results = {dataset: [] for dataset in datasets}
    for dataset in datasets:
        for i in tqdm(range(10)):
            acc = classify(dataset)
            results[dataset].append(acc)

    # 计算每个数据集的均值和标准差
    for dataset, accs in results.items():
        mean_acc = np.mean(accs)
        std_acc = np.std(accs)
        results[dataset] = [mean_acc, std_acc]  # 更新字典，只保留均值和标准差

    # 将结果保存到CSV文件中
    for dataset, accs in results.items():
        df = pd.DataFrame({'Mean': [accs[0]], 'Std': [accs[1]]})
        df.to_csv(f'{dataset}_results.csv', index=False)


